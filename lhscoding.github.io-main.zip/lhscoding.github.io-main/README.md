# LHSCoding.github.io
## Largo High School Coding Club's website!

### Link to website: https://lhscoding.github.io

### Features
* **Announcements**
* **About Us**
* **Projects**
* **Contact Us**

### Contributors
* Lead Developer: **S-Orbital**
* Agenda & Bug Maintenance: **D4LM**
